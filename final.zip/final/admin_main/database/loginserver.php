<?php
session_start();

require 'conn.php';

$errors = array();

if (isset($_POST['adminlogin'])) {

	$adminid = $conn->real_escape_string($_POST['adminid']);
	$adminpassword = $conn->real_escape_string($_POST['adminpassword']);

	if (empty($adminid)) {
		array_push($errors, "Admin ID is required");
	}
	if (empty($adminpassword)) {
		array_push($errors, "Password is required");
	}

	if (count($errors) == 0) {
		$queryA = "SELECT * FROM `admin` WHERE adminid=('$adminid')AND pswd=('$adminpassword')";
		$resultA = mysqli_query($conn, $queryA);

		if (mysqli_num_rows($resultA) == 1) {
			$_SESSION['adminid'] = $adminid;
			$_SESSION['success'] = "you are now logged in";
			header('Location: ../admin/adminhome.php');
		} else {
			array_push($errors, "The ID/Password not correct");
		}
	}
}

?>
