<?php
require '../database/conn.php';
require '../database/loginserver.php';


if (!isset($_SESSION["adminid"])) {
	header("location: adminlogin.php");
}
?>
<!DOCTYPE html>
<html>

<head>
	<title>Admin</title>
	<link rel="stylesheet" type="text/css" href="../css/adminhome.css">
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
	
</head>

<header>
	<h1>A<span>NOC</span></h1>
	<nav>
		<ul>
			<li><a href="criminalsearch.php">View Crime Records</a></li>
			<li><a href="nocs.php">View NOC'S</a></li>
			<li><a href="appointments.php">View Appointments</a></li>
			<li><a href="useractivity.php">User Activity</a></li>
			<li><a href="logout.php">Logout</a></li>
		</ul>
	</nav>
</header>

<body>
	<form method="post" action="appointments.php" class="divclass">
		<div style="margin-left: 50px">
			<button type="submit" name="active" class="btn btn-primary" style="margin-right:30px">Active</button>
			<button type="submit" name="approved" class="btn btn-success" style="margin-right:20px">Approved</button>
			<button type="submit" name="rejected" class="btn btn-danger" style="margin-right:20px">Rejected</button>
		</div>
	</form>

	<!-- code for active button to show the pending appointments -->
	<?php
	if (isset($_POST['active'])) {
	?>
		<table class="table2">
			<tr>
				<th>Appointments ID</th>
				<th>User ID</th>
				<th>Date</th>
				<th>Time</th>
				<th>Higher Autority Person</th>
				<th>Reason</th>
				<th>Approve</th>
				<th>Reject</th>
			</tr>
			<?php
			$sql = "SELECT * FROM appointment where status ='' ";
			$result = mysqli_query($conn, $sql);

			if (mysqli_num_rows($result) > 0) {
				// output data of each row
				while ($row = mysqli_fetch_assoc($result)) {
					echo "<tr>";
					echo '<td>' . $row['app_id'] . '</td>';
					echo '<td>' . $row['u_id'] . '</td>';
					echo '<td>' . $row['app_date'] . '</td>';
					echo '<td>' . $row['app_time'] . '</td>';
					echo '<td>' . $row['app_hap'] . '</td>';
					echo '<td>' . $row['reason'] . '</td>';
			?>
					<form method="post" action="appointments.php">
						<input type="hidden" name="app_id" value=<?php echo $row["app_id"]; ?> >
						<td> <button type="submit" name="Approve" value="Approve" class="btnA1">Approve</button> </td>
						<td> <button type="submit" name="Reject" class="btnA1"> Reject </button> </td>
					</form>
					</tr>



		<?php
				}
			}
		}
		?>
		</table>

		<!-- code for approved button to show the approved appointments -->

		<?php
		if (isset($_POST['approved'])) {
		?>
			<table class="table2">
				<tr>
					<th>Appointments ID</th>
					<th>User ID</th>
					<th>Date</th>
					<th>Time</th>
					<th>Higher Autority Person</th>
					<th>Reason</th>
				</tr>
			<?php
			$sql = "SELECT * FROM appointment where status ='approve' ";
			$result = mysqli_query($conn, $sql);

			if (mysqli_num_rows($result) > 0) {
				// output data of each row
				while ($row = mysqli_fetch_assoc($result)) {
					echo "<tr>";
					echo '<td>' . $row['app_id'] . '</td>';
					echo '<td>' . $row['u_id'] . '</td>';
					echo '<td>' . $row['app_date'] . '</td>';
					echo '<td>' . $row['app_time'] . '</td>';
					echo '<td>' . $row['app_hap'] . '</td>';
					echo '<td>' . $row['reason'] . '</td>';
				}
			}
		}
			?>
			</table>
		
			<!-- code for rejected button to show the rejected appointments -->
			<?php
			if (isset($_POST['rejected'])) {
			?>
				<table class="table2">
					<tr>
						<th>Appointments ID</th>
						<th>User ID</th>
						<th>Date</th>
						<th>Time</th>
						<th>Higher Autority Person</th>
						<th>Reason</th>
					</tr>
				<?php
				$sql = "SELECT * FROM appointment where status ='reject' ";
				$result = mysqli_query($conn, $sql);

				if (mysqli_num_rows($result) > 0) {
					// output data of each row
					while ($row = mysqli_fetch_assoc($result)) {
						echo "<tr>";
						echo '<td>' . $row['app_id'] . '</td>';
						echo '<td>' . $row['u_id'] . '</td>';
						echo '<td>' . $row['app_date'] . '</td>';
						echo '<td>' . $row['app_time'] . '</td>';
						echo '<td>' . $row['app_hap'] . '</td>';
						echo '<td>' . $row['reason'] . '</td>';
					}
				}
			}

				?>
				</table>



				<!-- ********Code for Approve and Reject Appointments****** -->

				<?php
				
					// Code for Approve the Appointments	
								 
				if (isset($_POST["Approve"])) {

					$id = $_POST['app_id'];
					$sql = "UPDATE appointment SET status='approve' WHERE app_id= $id";
					if (mysqli_query($conn, $sql)) {
						echo '<script>
					alert("Appointment Approved Successfully")
				</script>';
						sleep(3);
						header("location: appointments.php");
					} else {
						echo '<script>
					alert("Error updating record")
				</script>';
					}
				}

				// Code for Reject the Appointments	

				if (isset($_POST["Reject"])) {

					$id = $_POST['app_id'];
					$sql = "UPDATE appointment SET status='reject' WHERE app_id= $id";
					if (mysqli_query($conn, $sql)) {
						echo '<script>
					alert("Appointment Rejected Successfully")
				</script>';
						header("location: appointments.php");
					} else {
						echo '<script>
					alert("Error updating record")
				</script>';
						header("location: appointments.php");
					}
				}

				?>





</body>

</html>