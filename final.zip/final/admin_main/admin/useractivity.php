<?php
require '../database/conn.php';
require '../database/loginserver.php';

if (!isset($_SESSION["adminid"])) {
    header("location: adminlogin.php");
}
?>

<!DOCTYPE html>
<html>

<head>
    <title>Admin</title>
    <link rel="stylesheet" type="text/css" href="../css/adminhome.css">
    <link href="https://fonts.googleapis.com/css2?family=Alfa+Slab+One&family=Open+Sans:wght@300&display=swap" rel="stylesheet">
</head>

<header>
    <h1>A<span>NOC</span></h1>
    <nav>
        <ul>
            <li><a href="criminalsearch.php">View Crime Records</a></li>
            <li><a href="nocs.php">View NOC'S</a></li>
            <li><a href="appointments.php">View Appointments</a></li>
            <li><a href="useractivity.php">User Activity</a></li>
            <li><a href="logout.php">Logout</a></li>
        </ul>
    </nav>
</header>

<body>
    <h1 style="margin-left:40% ;margin-top:80px" class="asd"> Appointments </h1>
    <table class="table4">
        <tr>
            <th>User ID</th>
            <th>NAME</th>
            <th>DOB</th>
            <th>Phone Number</th>
            <th>Address</th>
            <th>Email</th>
            <th>Gender</th>
            <th>Password</th>
        </tr>
        <?php

        $sql4 = "SELECT * FROM user";
        $result4 = mysqli_query($conn, $sql4);

        if (mysqli_num_rows($result4) > 0) {
            // output data of each row
            while ($row3 = mysqli_fetch_assoc($result4)) {
                //  echo "<tr><td>" . $row3["u_id"] . "</td><td>" . $row3["fullname"] . "</td><td>" . $row3["dob"] . "</td><td>" . $row3["phonenumber"] . "</td><td>" . $row3["address"] . "</td><td>" . $row3["email"] . "</td><td>" . $row3["gender"] . "</td><td>" . $row3["password"] . "</td></tr>";
                echo "<tr><td>" . $row3["u_id"] . "</td><td>" . $row3["fullname"] . "</td><td>" . $row3["dob"] . "</td><td>" . $row3["phonenumber"] . "</td><td>" . $row3["address"] . "</td><td>" . $row3["email"] . "</td><td>" . $row3["gender"] . "</td><td>" . $row3["password"] . "</td></tr>";
            }
        } else {
            echo "0 results";
        }

        mysqli_close($conn);
        ?>
    </table>
</body>

</html>