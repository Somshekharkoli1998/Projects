<?php
require '../database/conn.php';
require '../database/loginserver.php';

if (!isset($_SESSION["adminid"])) {
	header("location: adminlogin.php");
}

?>
<!DOCTYPE html>
<html>

<head>
	<title>Admin</title>
	<link rel="stylesheet" type="text/css" href="../css/adminhome.css">
	<link href="https://fonts.googleapis.com/css2?family=Alfa+Slab+One&family=Open+Sans:wght@300&display=swap" rel="stylesheet">
</head>

<header>
	<h1>A<span>NOC</span></h1>
	<nav>
		<ul>
			<li><a href="criminalsearch.php">View Crime Records</a></li>
			<li><a href="nocs.php">View NOC'S</a></li>
			<li><a href="appointments.php">View Appointments</a></li>
			<li><a href="useractivity.php">User Activity</a></li>
			<li><a href="logout.php">Logout</a></li>
		</ul>
	</nav>
</header>

<body>
	</table>
</body>

</html>