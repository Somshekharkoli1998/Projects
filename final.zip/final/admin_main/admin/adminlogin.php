<?php
include('../database/loginserver.php')
?>

<!DOCTYPE html>
<html>

<head>
	<title>Admin</title>
	<link rel="stylesheet" type="text/css" href="../css/admin.css">
</head>

<body class="Abody">
	<div class="Aheader">
		<h2>Admin Login</h2>
	</div>

	<?php /* form starts */ ?>
	<form method="post" action="adminlogin.php" class="Aform">
		<?php
		include('../database/errors.php')
		?>
		<div class="input-groupA">
			<label>Admin ID</label>
			<input type="text" name="adminid"> <?php /* it takes admin id */ ?>
		</div>

		<div class="input-groupA">
			<label>Password</label>
			<input type="Password" name="adminpassword"> <?php /* it takes admin password */ ?>

			<div class="input-groupA">
				<button type="submit" name="adminlogin" class="btnA"> Login</button> <?php /* it is button login */ ?>
			</div>

	</form>
	<?php /* form ends */ ?>
	
</body>

</html>