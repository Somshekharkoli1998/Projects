<!DOCTYPE html>
<html>

<head>
    <title>ANOC</title>
    <style>
/*text Animation */
#instructions {
	position: absolute;
	color: #666;
	bottom: 0;
	padding-bottom: 6px;
	font-family: sans-serif;
	width: 100%;
	text-align: center;
	pointer-events: none;
}

    /* Style the body */
    body {
        font-family: Arial;
        margin: 0;
        background: whitesmoke;
        overflow: hidden;
    }

    /* Header/Logo Title */
    .header {
        padding: 60px;
        text-align: center;
        font-size: 30px;
        font-family: Impact, Charcoal, sans-serif;
        font-size: 30px;
        letter-spacing: 0px;
        word-spacing: 3px;
        color: #0068FF;
        font-weight: 700;
        text-decoration: none solid rgb(174, 173, 170);
        font-style: italic;
        font-variant: normal;
        text-transform: none;
    }

    /* Page Content */
    .content {
        padding: 20px;
    }

    .btn1 {
        border: 2px solid black;
        background-color: white;
        color: black;
        padding: 10px 20px;
        font-size: 15px;
        cursor: pointer;
        margin-top: 8%;
        height: 50px;
        width: 150px;
    }

    /* Blue */
    .spb {
        display: inline;
        border-color: #2196F3;
        color: dodgerblue;
        line-height: 100%;
        margin-left: 0%;

    }

    .spb:hover {
        background: #2196F3;
        color: white;
    }

    /* Blue */
    .ab {
        display: inline;
        border-color: #2196F3;
        color: dodgerblue;
        line-height: 100%;
        margin-left: 20%;
    }

    .ab:hover {
        background: #2196F3;
        color: white;
    }
    </style>
</head>

<body>

    <div class="header">
        <h1>ANOC</h1>
        <h1>PANEL</h1>
        <button onclick="window.location.href='super_admin_main/superadmin/superadminlogin.php'" class="btn1 spb">SUPER ADMIN</button>
        <button onclick="window.location.href='admin_main/admin/adminlogin.php'" class="btn1 ab">ADMIN</button>
</body>

</html>