<?php
session_start();

require 'conn.php';

$errors = array();


if (isset($_POST['superadminlogin'])) {

    $superadminid = $conn->real_escape_string($_POST['superadminid']);
    $superadminpassword = $conn->real_escape_string($_POST['superadminpassword']);


    if (empty($superadminid)) {
        array_push($errors, "Super Admin ID is required");
    }
    if (empty($superadminpassword)) {
        array_push($errors, "Password is required");
    }
    if (count($errors) == 0) {
        $query4 = "SELECT * FROM superadmin WHERE superadminid=('$superadminid') AND superadminpassword=('$superadminpassword')";
        $result4 = mysqli_query($conn, $query4);

        if (mysqli_num_rows($result4) == 1) {
            $_SESSION['superadminid'] = $superadminid;
            $_SESSION['success'] = "you are now logged in";
            header("Location: ../superadmin/superhome.php");
        } else {
            array_push($errors, "The ID/Password not correct");
        }
    }
}
