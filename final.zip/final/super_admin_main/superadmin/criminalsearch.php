<?php
require '../database/conn.php';
require '../database/superserver.php';

if (!isset($_SESSION["superadminid"])) {
	header("Location: superadminlogin.php");
}
?>

<!DOCTYPE html>
<html>

<head>
	<title>Admin</title>
	<link rel="stylesheet" type="text/css" href="../css/style.css">

	<link href="https://fonts.googleapis.com/css2?family=Alfa+Slab+One&family=Open+Sans:wght@300&display=swap" rel="stylesheet">
</head>

<header>
	<h1>A<span>NOC</span></h1>
	<nav>
		<ul>
			<li><a href="createadmin.php">Create Admin</a></li>
			<li><a href="viewadmin.php">View Admin</a></li>
			<li><a href="criminalsearch.php">View Crime Records</a></li>
			<li><a href="useractivity.php">View User </a></li>
			<li><a href="activity.php">Activity Log</a></li>
			<li><a href="logout.php">Logout</a></li>
		</ul>
	</nav>
</header>

<body>
	<form method="post" action="criminalsearch.php" class="search_criminal_name">
		<div class="input-group">
			<label>Search By:<br>Criminal Name : </label>
			<input type="text" name="criminal_name">
		</div>

		<div class="input-group">
			<button type="submit" name="c_name" class="btnA" style="padding: 5px;margin-left: 90px;margin-top: 20px; padding-left: 15px; padding-right: 15px">Search</button>
		</div>
	</form>



	<table class="table2">
		<tr>
			<th>Criminal name</th>
			<th>Criminal DOB</th>
			<th>Criminal Phone_No</th>
			<th>Case Section</th>
			<th>Victim Name</th>
		</tr>
		<?php

		if (isset($_POST['c_name'])) {

			$criminal_name = mysqli_real_escape_string($conn, $_POST['criminal_name']);

			$sql = "SELECT * FROM `criminal` WHERE criminal_name=('$criminal_name') ";
			$result = mysqli_query($conn, $sql);
			if (mysqli_num_rows($result) > 0) {
				// output data of each row
				while ($row = mysqli_fetch_assoc($result)) {
					echo "<tr><td>" . $row["criminal_name"] . "</td><td>" . $row["criminal_dob"] . "</td><td>" . $row["criminal_phnumber"] . "</td><td>" . $row['case_section'] . "</td><td>" . $row['victim_name'] . "</td></tr>";
				}
				echo "</table";
			} else {
				echo '<script>alert("Record Not Found")</script>';
			}
		} else {
			$sql = "SELECT * FROM criminal";
			$result = mysqli_query($conn, $sql);
			if (mysqli_num_rows($result) > 0) {
				// output data of each row
				while ($row1 = mysqli_fetch_assoc($result)) {
					echo "<tr><td>" . $row1["criminal_name"] . "</td><td>" . $row1["criminal_dob"] . "</td><td>" . $row1["criminal_phnumber"] . "</td><td>" . $row1['case_section'] . "</td><td>" . $row1['victim_name'] . "</td></tr>";
				}
			}
		}

		?>
	</table>
</body>

</html>