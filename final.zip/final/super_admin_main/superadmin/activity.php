<?php
require '../database/conn.php';
require '../database/superserver.php';

if (!isset($_SESSION["superadminid"])) {
    header("Location: superadminlogin.php");
}

?>
<!DOCTYPE html>
<html>

<head>
    <title>Log Activity</title>
    <link rel="stylesheet" type="text/css" href="../css/style.css">

    <link href="https://fonts.googleapis.com/css2?family=Alfa+Slab+One&family=Open+Sans:wght@300&display=swap" rel="stylesheet">
</head>

<header>
    <h1>A<span>NOC</span></h1>
    <nav>
        <ul>
            <li><a href="createadmin.php">Create Admin</a></li>
            <li><a href="viewadmin.php">View Admin</a></li>
            <li><a href="criminalsearch.php">View Crime Records</a></li>
            <li><a href="useractivity.php">View User </a></li>
            <li><a href="activity.php">Activity Log</a></li>
            <li><a href="logout.php">Logout</a></li>
        </ul>
    </nav>
</header>

<table class="table2">
    <tr>
        <th>Event Time</th>
        <th>User Host</th>
        <th>Thread Id/th>
        <th>Server Id</th>
        <th>Command Type</th>
        <th>Argument</th>
    </tr>

    <?php

    $sql1 = "SELECT * FROM mysql.general_log";
    $result = mysqli_query($conn, $sql1);
    if (mysqli_num_rows($result) > 0) {
        // output data of each row
        while ($row = mysqli_fetch_assoc($result)) {
            echo "<tr><td>" . $row["event_time"] . "</td><td>" . $row["user_host"] . "</td><td>" . $row["thread_id"] . "</td><td>" . $row['server_id'] . "</td><td>" . $row['command_type'] . "</td><td>" . $row['argument'] . "</td></tr>";
        }
        echo "</table";
    } else {
        echo '<script>alert("Record Not Found")</script>';
    }

    ?>
</table>
</body>

</html>