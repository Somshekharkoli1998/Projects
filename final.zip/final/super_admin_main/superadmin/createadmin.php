<?php
require '../database/conn.php';
require '../database/superserver.php';

if (!isset($_SESSION["superadminid"])) {
	header("Location: superadminlogin.php");
}
?>

<!DOCTYPE html>
<html>

<head>
	<title>Admin</title>
	<link rel="stylesheet" type="text/css" href="../css/style.css">

	<link href="https://fonts.googleapis.com/css2?family=Alfa+Slab+One&family=Open+Sans:wght@300&display=swap" rel="stylesheet">
</head>

<header>
	<h1>A<span>NOC</span></h1>
	<nav>
		<ul>
			<li><a href="createadmin.php">Create Admin</a></li>
			<li><a href="viewadmin.php">View Admin</a></li>
			<li><a href="criminalsearch.php">View Crime Records</a></li>
			<li><a href="useractivity.php">View User </a></li>
			<li><a href="activity.php">Activity Log</a></li>
			<li><a href="logout.php">Logout</a></li>
		</ul>
	</nav>
</header>

<body>

	<form method="post" action="createadmin.php" class="Aform">
		<div class="headerA">
			<h2>Create Admin </h2>
		</div>
		<div class="input-groupA">
			<label>Admin ID</label>
			<input type="text" name="adminid">
		</div>

		<div class="input-groupA">
			<label>Admin Name</label>
			<input type="text" name="name">
		</div>

		<div class="input-groupA">
			<label>Contact Number</label>
			<input type="text" name="number">
		</div>

		<div class="input-groupA">
			<label>Post of Admin </label>
			<select name="postofadmin" class="xd">
				<option value="SI">SI(Superendant Of Police</option>
				<option value="PI">Police Inspector</option>
				<option value="Api">Assistent Police Inspector</option>
				<option value="PSI">Police Sub Inspector</option>
				<option value="other">other</option>
			</select>
		</div>

		<div class="input-groupA">
			<label>Password</label>
			<input type="text" name="password">
		</div>
		<div class="input-groupA">
			<button type="submit" name="createadmin" class="btnA">Add Admin</button>
		</div>
	</form>

	<?php
	if (isset($_POST["createadmin"])) {
		$a_id = $_POST["adminid"];
		$a_name = $_POST["name"];
		$a_phnumber = $_POST["number"];
		$a_post = $_POST["postofadmin"];
		$a_pswd = $_POST["password"];

		//mysql insert query

		if (isset($a_id) and isset($a_name) and isset($a_phnumber) and isset($a_post) and isset($a_pswd)) {

			$sql = "SELECT * FROM admin WHERE adminid = '$a_id' or number = '$a_phnumber'";
			$result = mysqli_query($conn, $sql);
			$count = mysqli_num_rows($result);
			if ($count >= 1) {
				echo '<script>alert("ID or Phonenumber already exist, try something else.")</script>';
			}
			/*  if admin is not existed then admin is created  */ else {

				$sql = "INSERT INTO `admin`(`adminid`, `fullname`, `number`, `postofadmin`, `pswd`) 
							        VALUES ('$a_id', '$a_name', '$a_phnumber','$a_post','$a_pswd')";


				if (mysqli_query($conn, $sql)) {
					echo '<script>alert("Admin Created Successfully.")</script>';
				} else {
					echo "Error: " . $sql . "<br>" . mysqli_error($conn);
				}
			}
		}
	}
	mysqli_close($conn);
	?>

</body>

</html>