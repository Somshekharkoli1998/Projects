<?php
require '../database/conn.php';
require '../database/superserver.php';

if (!isset($_SESSION["superadminid"])) {
	header("Location: superadminlogin.php");
}
?>

<!DOCTYPE html>
<html>

<head>
	<title>Admin</title>
	<link rel="stylesheet" type="text/css" href="../css/style.css">

	<link href="https://fonts.googleapis.com/css2?family=Alfa+Slab+One&family=Open+Sans:wght@300&display=swap" rel="stylesheet">
</head>

<header>
	<h1>A<span>NOC</span></h1>
	<nav>
		<ul>
			<li><a href="createadmin.php">Create Admin</a></li>
			<li><a href="viewadmin.php">View Admin</a></li>
			<li><a href="criminalsearch.php">View Crime Records</a></li>
			<li><a href="useractivity.php">View User </a></li>
			<li><a href="activity.php">Activity Log</a></li>
			<li><a href="logout.php">Logout</a></li>
		</ul>
	</nav>
</header>

<body>
	<h1 style="margin-left:35% ;margin-top:80px" class="asd">Admin Information</h1>
	<table class="table4">
		<tr>
			<th>Admin ID</th>
			<th>Name</th>
			<th>Number</th>
			<th>Post Of Admin</th>
			<th>Password</th>
		</tr>

		<?php
		$sql = "SELECT * FROM admin";
		$result = mysqli_query($conn, $sql);

		if (mysqli_num_rows($result) > 0) {
			// output data of each row
			while ($row3 = mysqli_fetch_assoc($result)) {
				echo "<tr><td>" . $row3["adminid"] . "</td><td>" . $row3["fullname"] . "</td><td>" . $row3["number"] . "</td><td>" . $row3["postofadmin"] . "</td><td>" . $row3["pswd"] . "</td></tr>";
			}
		} else {
			echo "0 results";
		}

		mysqli_close($conn);
		?>

	</table>
</body>

</html>