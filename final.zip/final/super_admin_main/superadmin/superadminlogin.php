<?php
include('../database/superserver.php');
?>

<!DOCTYPE html>
<html>

<head>
	<title>Super Admin</title>
	<link rel="stylesheet" type="text/css" href="../css/super.css">
</head>

<body style="margin-top:10%">
	<div class="Aheader">
		<h2>Super Admin Login</h2>
	</div>

	<?php /* form starts */ ?>
	<form method="post" action="superadminlogin.php" class="Aform">

		<?php include('../database/errors.php') ?>

		<div class="input-groupA">
			<label>Super Admin ID</label>
			<input type="text" name="superadminid"> <?php /* it takes SUPER admin id */ ?>
		</div>

		<div class="input-groupA">
			<label>Password</label>
			<input type="Password" name="superadminpassword"> <?php /* it takes SUPER admin password */ ?>

			<div class="input-groupA">
				<button type="submit" name="superadminlogin" class="btnA"> Login</button>
				<?php /* it is button login */ ?>
			</div>

	</form>
	<?php /* form ends */ ?>
</body>

</html>